package com.finance.quote;

import java.util.Date;
import java.util.Random;

import com.finance.vo.Stock;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.format.Time;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class StockQuoteActivity extends Activity {
    /** Called when the activity is first created. */
	//public EditText editText = null;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        final TextView textView = (TextView)findViewById(R.id.textView1);
        final EditText editText = (EditText)findViewById(R.id.editText1);
        Button myButton = (Button)findViewById(R.id.button1);
        
        final Handler handler = new Handler() {
			public void handleMessage(Message message) {
				textView.setText(String.format("%.2f", ((Stock)message.obj).getPrice()));
			}
		};
	    
		//final MyThread myThread = new MyThread(handler);

        
        
        
        myButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
            	showToast(StockQuoteActivity.this, "Looking up symbol: " + editText.getText());
            	new MyThread(handler).start();
            }
        });
       
        
        
        System.out.println("Activity Ended");
    }
    
    private void showToast(Context context, CharSequence msg) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }
}

final class MyThread extends Thread {
	Handler handler;
	Time time = new Time();
	
	MyThread(Handler h) {
		handler = h;
		
	}
   
	public void run() {
		for (;;) {
			try {
				//1000 milliseconds == 1 second
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				Log.e("ERROR", "Thread Interrupted");
			}

			
			System.out.println("time now is " + new Date());
			final Message message = handler.obtainMessage(); //Get an empty Message.
			
			//TODO: fetch value from stock quotes app
			final Random myRandom = new Random();
			Stock newStock = new Stock();
			newStock.setPrice(myRandom.nextFloat()*100);
			
			message.obj = newStock;	
			handler.sendMessage(message);	//Calls handleMessage
			break;
		}
	}
}



