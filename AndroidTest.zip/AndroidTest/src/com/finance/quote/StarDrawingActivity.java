package com.finance.quote;

import com.finance.view.StarView;

import android.app.Activity;
import android.os.Bundle;

public class StarDrawingActivity extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//setContentView(R.layout.main);
		
		StarView starView = new StarView(this);
		setContentView(starView);
	}
}
