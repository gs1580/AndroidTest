package com.finance.quote;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.Toast;

public class OptionsMenuActivity extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.optionsmenu, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle item selection

		LinearLayout layout = (LinearLayout)findViewById(R.id.layout);
		
		switch (item.getItemId()) {
		case R.id.red:
			Toast.makeText(this, "Red", Toast.LENGTH_SHORT).show();
			layout.setBackgroundColor(Color.RED);
			return true;

		case R.id.green:
			Toast.makeText(this, "Green", Toast.LENGTH_SHORT).show();
			layout.setBackgroundColor(Color.GREEN);
			return true;

		case R.id.blue:
			Toast.makeText(this, "Blue", Toast.LENGTH_SHORT).show();
			layout.setBackgroundColor(Color.BLUE);
			return true;

		case R.id.white:
			Toast.makeText(this, "White", Toast.LENGTH_SHORT).show();
			layout.setBackgroundColor(Color.WHITE);
			return true;

		default:
			return super.onOptionsItemSelected(item);
		}
	}
}
