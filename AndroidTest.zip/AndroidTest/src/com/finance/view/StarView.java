package com.finance.view;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;
import android.view.View;


public class StarView extends View {
	Context context;

	public StarView(Context context) {
		super(context);
		this.context = context;
	}

	@Override
	protected void onDraw(Canvas canvas) {
		final int width = getWidth();
		final int height = getHeight();

		//white background
		canvas.drawColor(Color.BLUE);
		canvas.translate(width / 2.0f-120, height / 2.0f-100);

		//canvas.scale(1, -1);
		canvas.skew(.1f, .5f);
		//canvas.rotate(45);

		//red stars
		Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		
		paint.setColor(Color.WHITE);
		PointF center = new PointF(0, 0);
		final float radius = height / 50.0f;

		
		for (int k=0;k<9;k++){
			int n=(k%2==0)?6:5;
			int offset= (k%2==0)?0:25;
			for (int j=0;j<n;j++){
				Path path = new Path();
				int i;
				for (i = 0; i <= 2 * 5; i += 2) {
					final double theta = 2 * Math.PI * i / 5;	//in radians
					final float x = center.x + radius * (float)Math.cos(theta);
					final float y = center.y - radius * (float)Math.sin(theta); 
		
					if (i == 0) {
						path.moveTo(x+ 50*j + offset, y + 30*k);
					} else {
						path.lineTo(x+ 50*j+ offset, y+ 30*k);
					}
				}
				canvas.drawPath(path, paint);
				i=0;
			}
		}
		
	}

}
