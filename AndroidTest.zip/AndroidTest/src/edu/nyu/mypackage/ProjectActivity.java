package edu.nyu.mypackage;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

public class ProjectActivity extends Activity {
    /** Called when the activity is first created. */
	
	private static final String TAG = "ProjectActivity";
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Toast.makeText(this, "ProjectActivity:onCreate running via Toast", Toast.LENGTH_SHORT).show();
        
        TextView myTextView = (TextView)findViewById(R.id.mytextview01);
        myTextView.setText("ProjectActivity:onCreate running via myTextView");
        Log.d(TAG, "ProjectActivity:onCreate running via Log.d");
        
   }
}