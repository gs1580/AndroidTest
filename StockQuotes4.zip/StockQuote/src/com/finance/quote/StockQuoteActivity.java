package com.finance.quote;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Date;
import java.util.Random;

import com.finance.vo.Stock;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.format.Time;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class StockQuoteActivity extends Activity {
    /** Called when the activity is first created. */
	EditText editText = null;
	Stock displayStock = null;
	TextView textView = null;
	boolean[] displayChoice = new boolean[7];
	
	private static final int DIALOG_MULTIPLE_CHOICE = 1;

	
	public void updateTextView(){
		textView = (TextView)findViewById(R.id.textView1);	
		
		StringBuilder sb = new StringBuilder();
		if (displayChoice[0]==true){
			sb.append("Symbol:").append(displayStock.getSymbol()).append(",");
		}
		if (displayChoice[1]==true){
			sb.append("Name:").append(displayStock.getName()).append(",");
		}
		if (displayChoice[2]==true){
			sb.append("Last Trade Date:").append(displayStock.getLastTradeDate()).append(",");
		}
		if (displayChoice[3]==true){
			sb.append("Last Traded At:").append(displayStock.getLastTradedAt()).append(",");
		}
		if (displayChoice[4]==true){
			sb.append("Dividend Yield:").append(displayStock.getDivYield()).append(",");
		}
		if (displayChoice[5]==true){
			sb.append("P/E Ratio:").append(displayStock.getPEratio()).append(",");
		}
		
		textView.setText(sb.toString());
		
	}
	
	
	@Override
    protected Dialog onCreateDialog(int id) {
		
		  final Handler handler = new Handler() {
				public void handleMessage(Message message) {
					//textView.setText(String.format("%.2f", ((Stock)message.obj).getPrice()));
					StockQuoteActivity.this.displayStock  = (Stock)message.obj;
					StockQuoteActivity.this.updateTextView();
				}
			};
			
		editText = (EditText)findViewById(R.id.editText1);	
			
		final boolean [] choice = new boolean[]{false, true, false, true, false, false, false};
        switch (id) {
        case DIALOG_MULTIPLE_CHOICE:
            return new AlertDialog.Builder(StockQuoteActivity.this)
                .setIcon(R.drawable.dollar)
                .setTitle(R.string.alert_dialog_multi_choice)
                .setMultiChoiceItems(R.array.select_dialog_items,
                		choice,
                        new DialogInterface.OnMultiChoiceClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton,
                                    boolean isChecked) {

                                /* User clicked on a check box do some stuff */
                            	StockQuoteActivity.this.displayChoice = choice;
                          }
                        })
                .setPositiveButton(R.string.alert_dialog_ok,
                        new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {

                        /* User clicked Yes so do some stuff */
                    	
                    	new MyThread(handler, editText.getText().toString(), StockQuoteActivity.this.displayChoice).start();
                    	
                    	
                    }
                })
                .setNegativeButton(R.string.alert_dialog_cancel,
                        new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {

                        /* User clicked No so do some stuff */ 
                    }
                })
               .create();
        }
        return null;
   }
	
		
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
               
        Button myButton = (Button)findViewById(R.id.button1);
       
        myButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
            	//showToast(StockQuoteActivity.this, "Looking up symbol: " + editText.getText());
            	showDialog(DIALOG_MULTIPLE_CHOICE);
            }
        });
       
        
        
        System.out.println("StockQuoteActivity Activity Ended");
    }
    
    private void showToast(Context context, CharSequence msg) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }
}

final class MyThread extends Thread {
	Handler handler = null;
	String symbol = null;
	boolean[] displayChoice = null;
	
	
	MyThread(Handler h, String symbol, boolean[] displayChoice) {
		handler = h;
		this.symbol = symbol; 
		this.displayChoice = displayChoice;
		
	}
   
	public void run() {
		for (;;) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				Log.e("ERROR", "Thread Interrupted");
			}

			
			System.out.println("symbol requested:" + symbol);
			
			
			final Message message = handler.obtainMessage(); //Get an empty Message.
			
			StringBuilder url = new StringBuilder("http://finance.yahoo.com/d/quotes.csv?");
			
			url.append("s=").append(symbol).append("&f=");
			
			if (displayChoice[0]==true){
				url.append("s");
			}
			if (displayChoice[1]==true){
				url.append("n");
			}
			if (displayChoice[2]==true){
				url.append("d1");
			}
			if (displayChoice[3]==true){
				url.append("l1");
			}
			if (displayChoice[4]==true){
				url.append("y");
			}
			if (displayChoice[5]==true){
				url.append("r");
			}
			URL yahoo = null;
			
			try{
				yahoo = new URL(url.toString());
			
				URLConnection yc = yahoo.openConnection();
		        BufferedReader in = new BufferedReader(
		                                new InputStreamReader(
		                                yc.getInputStream()));
		        String inputLine;
	
		        while ((inputLine = in.readLine()) != null) 
		            System.out.println(inputLine);
		        in.close();
			
			}catch(Exception e){
				System.out.print("exception accessing url" + yahoo);
				e.printStackTrace();
			}

			
			
			
			//TODO: fetch value from stock quotes app
			final Random myRandom = new Random();
			Stock newStock = new Stock();
			newStock.setSymbol("YHOO");
			newStock.setLastTradedAt(NumberFormat.getCurrencyInstance().format((myRandom.nextFloat()*100)));
			newStock.setDivYield(1.2);
			newStock.setLastTradeDate(DateFormat.getDateTimeInstance().format(new Date()));
			newStock.setName("YAHOO");
			newStock.setPEratio(12.5); 
			
			
			
			message.obj = newStock;	
			handler.sendMessage(message);	//Calls handleMessage
			break;
		}
	}
}



